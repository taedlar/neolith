# Stage 5: Shared Resolver Behavior Matrix

**Purpose**: Document expected runtime behavior of the shared resolver across build variants and DNS operation classes.

**Context**: This document captures Stage 5 behavior specifications and implementation tracking. For persistent architecture reference, see [../internals/addr-resolver.md](../internals/addr-resolver.md).

**Dimensions**:
1. **Build-time**: `HAVE_CARES` defined vs undefined
2. **DNS Operations**: three classes (Forward Lookup, Reverse Lookup, Peer Refresh)
3. **Execution guarantees**: non-blocking, admission control, deterministic completion

---

## DNS Operation Classes

### Class 1: Forward Lookup (socket_connect + resolve)
**Trigger**:
- `socket_connect(fd, "hostname <port>", read_cb, write_cb)` (mandatory hostname support)
- `resolve("hostname")`
**Operation**: resolve hostname to IPv4/IPv6 before connect or callback completion.
**Caller Contract**:
- Non-blocking; completion via socket write-select path (`socket_connect`) or resolver callback (`resolve`).
- Deterministic terminal state: success, timeout, canceled, malformed-address rejection.
- Admission: global cap 64, queue limit 256, plus caller-scope caps.

---

### Class 2: Reverse Lookup (auto cache + query_ip_name)
**Trigger**:
- Auto reverse refresh on interactive connection lifecycle
- `query_ip_name(ip_string)` cache miss path
**Operation**: resolve IP back to hostname and refresh driver cache.
**Caller Contract**:
- Non-blocking.
- `query_ip_name()` returns immediately (cached hostname or numeric IP fallback) and schedules async refresh on miss.
- Deterministic terminal state: success, timeout, canceled, admission reject.

---

### Class 3: Peer Refresh
**Trigger**: principal user descriptor refresh events (for example heartbeat-driven refresh policy).
**Operation**: periodic/coalesced hostname refresh for active peers.
**Caller Contract**:
- Non-blocking background operation.
- Deterministic cache update behavior with timeout-safe fallback.
- Coalescing allowed with Class 2 reverse lookups for the same IP.

---

## Behavior Matrix: WITH c-ares (HAVE_CARES defined)

| Class | Operation | Backend | Blocking | Completion | Admission | Error Handling | Notes |
|-------|-----------|---------|----------|-----------|-----------|----------------|-------|
| **1** | Forward Lookup | c-ares worker queue | non-blocking | socket write-select or resolver callback | central shared-resolver admission: global 64 + per-class quotas (runtime-configurable defaults: FWD 10, REV 4, REFRESH 2) | malformed input, admission reject, timeout, canceled map deterministically | driver-initiated forward requests may evict oldest queued task when saturated |
| **2** | Reverse Lookup | c-ares worker queue | non-blocking | cache entry update; immediate return for `query_ip_name()` | central shared-resolver admission (same policy as Class 1) | timeout leaves numeric fallback/cache unchanged | unifies auto reverse refresh and manual reverse refresh on cache miss |
| **3** | Peer Refresh | c-ares worker queue | non-blocking | background cache refresh | central shared-resolver admission (same policy as Class 1) | timeout keeps prior value | triggered on TTL-expired cache hits and coalesces with Class 2 when same IP is in-flight |

**Performance Profile (WITH c-ares)**:
- Typical latency: 10–100 ms per resolve (network + c-ares worker latency).
- Zero main-thread blocking; all latency absorbed by worker pool.
- Coalescing: multiple requests for same hostname wait on single worker result.
- Worst case (queue full): mudlib-initiated requests are rejected with `EERESOLVERBUSY`; driver-initiated forward requests can drop the oldest queued task.

---

## Behavior Matrix: WITHOUT c-ares (HAVE_CARES undefined)

| Class | Operation | Backend | Blocking | Completion | Admission | Error Handling | Notes |
|-------|-----------|---------|----------|-----------|-----------|----------------|-------|
| **1** | Forward Lookup | worker pool around libc resolver | non-blocking (worker-mediated) | socket write-select or resolver callback | central shared-resolver admission: global 64 + per-class quotas (runtime-configurable defaults: FWD 10, REV 4, REFRESH 2) | same deterministic mapping as with c-ares | driver-initiated forward requests may evict oldest queued task when saturated |
| **2** | Reverse Lookup | worker pool around libc resolver | non-blocking (worker-mediated) | cache entry update; immediate return for `query_ip_name()` | central shared-resolver admission (same policy as Class 1) | same timeout/cancel/admission semantics | higher latency only affects refresh timing |
| **3** | Peer Refresh | worker pool around libc resolver | non-blocking (worker-mediated) | background cache refresh | central shared-resolver admission (same policy as Class 1) | timeout keeps prior value | same semantics as with c-ares |

**Performance Profile (WITHOUT c-ares)**:
- Typical latency: 50–500 ms per resolve (getaddrinfo in worker + queue latency).
- Zero main-thread blocking; fallback uses worker-pool pattern identical to c-ares flow.
- Coalescing: identical to c-ares case (multiple requests coalesce on single worker result).
- Worst case (queue full): mudlib-initiated requests are explicitly rejected with `EERESOLVERBUSY`; driver-initiated forward requests can evict oldest queued task.

---

## Key Guarantees (Both Builds)

### Non-blocking Invariant
- Main event loop never calls blocking DNS functions (getaddrinfo, gethostbyname, reverse DNS).
- All DNS work queues to async worker; completion posts back via `async_runtime_post_completion()`.
- Even WITHOUT c-ares, fallback backend runs in worker thread (not main thread).

### Deterministic Completion
- Each DNS request reaches **exactly one** terminal state: success, timeout, canceled, or error.
- No stale completion fan-out after timeout or cancellation.
- Request-id correlation prevents stale results from reaching wrong owner/socket.

### Admission Control
- Centralized in shared resolver enqueue path (not socket-layer wrappers).
- Runtime-configurable per-class quotas with defaults: Forward 10, Reverse 4, Refresh 2; global in-flight cap remains 64.
- Queue size limit remains 256; mudlib-initiated requests reject on saturation, while driver-initiated forward lookups can evict oldest queued task.
- `query_ip_name()` remains fire-and-forget: miss/expiry scheduling failures stay silent and return-path remains immediate.

### Dedup/Coalescing
- Multiple requests for same hostname route to single worker future.
- All waiters complete together; no duplicate queries on network.
- Applies to socket connect forward lookups (high-impact volume case).

---

## Migration Impact: Behavior Changes

### Hostname Support in socket_connect() (Now Mandatory)
**Stage 4A / Stage 5**: Hostname support in `socket_connect(fd, "hostname <port>", ...)` is mandatory in all builds.
- **Motivation**: Mudlib convention of using simul_efun wrappers (resolve() + numeric connect) is no longer viable when resolve() becomes async-only in Stage 5.
- **Consequence**: Mudlibs can now assume hostname parsing is always available; no workarounds needed.
- **No compatibility break**: Existing numeric-IP arguments ("127.0.0.1 8000") continue to work unchanged.

### resolve() Efun (Async Contract Change)
**Current (Legacy blocking path)**:
```c
int resolve(string hostname) {
  // Blocking getaddrinfo call; may stall main loop for 100ms–1s
  return IPv4_address_integer;
}
```

**Stage 5 (Shared resolver async)**:
```c
int resolve(string hostname) {
  // Queue async request; return result or fire completion callback
  // Mudlib must handle async contract: result immediate (cached) or callback-based
}
```

**Incompatibility**: LPC code expecting synchronous return must change to consume callback.  
**Migration path**: 
- Direct usage: Mudlib can now use `socket_connect(fd, hostname, ...)` directly (no workaround needed).
- Legacy resolve() callers: Mudlib must implement async-aware wrapper (state machine or continuation-passing style) if synchronous return is required.

### query_ip_name() Efun
**Current**:
```c
string query_ip_name(string ip) {
  // May be cached (fast) or trigger blocking reverse lookup
  return cached_or_looked_up_hostname;
}
```

**Stage 5**:
```c
string query_ip_name(string ip) {
  // Return cached hostname when available.
  // On cache miss, return numeric IP immediately and schedule async reverse refresh.
}
```

**Compatibility impact**: No nil-on-miss contract is introduced; callers continue to receive a string immediately.  
**Mitigation**: Cache is populated/refreshed by background reverse-lookup worker; typical cache hit rate improves over steady-state traffic.

---

## Rejection and Error Mapping

### Admission Control Rejection
When queue is full or global cap exceeded:
- **Socket connect**: return `EERESOLVERBUSY`.
- **resolve()**: surface explicit resolver admission failure `EERESOLVERBUSY` via resolver completion/error contract.
- **query_ip_name()**: fire-and-forget scheduling remains silent on rejection/failure; immediate return contract stays unchanged.

### Timeout
- **Socket connect**: `EETIMEOUT` (to caller's `write_cb` or operation completion).
- **resolve()**: exception "resolver timeout".
- **query_ip_name()**: exception "resolver timeout"; cache remains unchanged.

### Cancellation
- **Socket connect**: `EECANCELED` if socket closed before DNS completion.
- **resolve()**: exception "resolver canceled" if owner object destructed.
- **query_ip_name()**: exception "resolver canceled" if owner object destructed.

---

## No Blocking Paths (Critical Constraint)

The following MUST NOT occur in Stage 5:
- ❌ No `getaddrinfo()` call on main thread.
- ❌ No `gethostbyname()` call on main thread.
- ❌ No `reverse_dns()` call on main thread.
- ❌ No legacy `addr_server_fd` event handling.
- ❌ No `query_addr_number()` internal path.
- ❌ No blocking fallback if c-ares unavailable; fallback uses worker pool instead.

---

## Stage 5 Unified Checklist

- [x] Verify c-ares is discoverable and linked (`FindCARES.cmake`, `HAVE_CARES`, stem link).
- [x] Add c-ares DNS task queue and worker pool (`cares_worker_main` in `addr_resolver.cpp`).
- [x] Implement shared forward-lookup and reverse-lookup request classes.
- [x] Implement fallback resolver worker using standard getaddrinfo.
- [x] Route fallback resolver through the same async worker pool pattern as c-ares.
- [x] Verify getaddrinfo calls only in worker threads (not main).
- [x] Complete shared resolver cache migration: add driver-owned forward/reverse TTL cache and keep `query_ip_name()` stable while cache ownership moves out of `src/comm.c`.
- [x] Define runtime-configurable resolver policy settings, pass them through `addr_resolver_init()` via a resolver settings struct, and source them from stem/runtime startup.
- [x] Run all three operation classes through fallback backend.
- [x] Verify non-blocking invariant holds for Stage 5 closeout (unit-test evidence via `RESOLVER_NOBLOCK_001`; production-load trace capture deferred to Stage 6 hardening).
- [ ] Document latency trade-off (higher without c-ares, but still responsive).
- [x] Build and test without c-ares variant.
- [x] Implement centralized shared-resolver admission control policy (global + per-class quotas, driver-priority drop behavior, and caller mapping).
- [x] Add dedup/coalescing for socket connect forward lookups (primary volume case).
- [x] Verify deterministic timeout and cancellation semantics across all classes (Stage 5 parity and timeout/cancel matrix complete; assertion strengthening deferred).
- [x] Complete resolver telemetry verification for forward/reverse cache hit, miss, stale-hit, and negative-hit behavior.
- [x] Verify no stale completion fan-out (request-id correlation).
- [x] Disable legacy `addr_server_fd` runtime path and legacy hname bridge.
- [x] Test all three operation classes under c-ares backend.
- [x] Verify non-blocking invariant by unit test: `RESOLVER_NOBLOCK_001` confirms enqueue returns in < 50 ms with 500 ms worker delay hook (both c-ares and fallback backends).
- [x] Route socket-connect DNS path through the same shared resolver request classes used by `resolve()` and reverse-refresh.
- [x] Document c-ares cache usage and OS resolver cache assumptions relative to shared resolver TTL policy (operator-facing guidance published).
- [x] Publish operator-facing behavior deltas for `resolve()` and `query_ip_name()` under Stage 5 async contract.

## Stage 5 Unified Verification Status (2026-03-24, all major cache and non-blocking work complete)

**Backend Implementation:**
- [x] `resolve()` requests run through shared resolver queue/results flow in `src/addr_resolver.cpp` with request-id correlation and safe pending-request release.
- [x] `query_ip_name()` cache misses enqueue reverse-lookup refresh and still return numeric IP immediately.
- [x] Legacy `addr_server_fd` event branch and hname parser bridge removed from runtime dispatch.
- [x] Legacy resolve() request bookkeeping removed from `src/comm.c`; resolver bookkeeping now owned by shared resolver module.
- [x] Resolver runtime policy settings now come from runtime config and are passed through stem into all shared resolver init paths via `addr_resolver_init()` config struct.
- [x] Shared resolver admission control is centralized in resolver enqueue paths; socket-layer global/per-owner DNS caps removed.
- [x] Runtime-configurable resolver quotas are wired through config/stem/init (defaults: Forward 10, Reverse 4, Refresh 2).
- [x] Resolver telemetry ownership moved to shared resolver core, including class-level reject and dropped counters plus forward/reverse cache hit/miss/negative counters.
- [x] `query_ip_name()` now uses peer refresh on TTL-expired cached entries while preserving immediate return semantics.
- [x] No-c-ares build verified with the full shared-resolver matrix green in the current build.
- [x] `socket_connect()` hostname DNS path now runs through shared resolver request-id completions instead of a socket-local DNS worker path.
- [x] Focused no-c-ares fallback concurrency coverage confirms independent progress when one blocking lookup is delayed.
- [x] c-ares backend (`cares_worker_main`) added to `addr_resolver.cpp` behind `#ifdef HAVE_CARES`.
- [x] `ares_library_init`/`ares_library_cleanup` called at `addr_resolver_init`/`addr_resolver_deinit` from main thread.
- [x] Build with `HAVE_CARES` (Ubuntu `libc-ares-dev`) succeeds; full test suite passes on Linux Debug config.
- [x] Windows `vs16-x64` build with `FETCH_CARES_FROM_SOURCE=v1.34.6` succeeds; full shared-resolver matrix passes.
- [x] Resolver-contract harness now initializes the shared resolver explicitly in isolated tests, making backend parity runs deterministic.
- [x] Forward cache integrated into `socket_connect()`: cache hit populates `r_addr` directly, skips DNS enqueue; `TT_COMM|3` trace on hit and miss.
- [x] Forward cache integrated into `query_addr_number()` (resolve efun): cache hit fires callback immediately and returns 0; `TT_COMM|3` trace on hit and miss.
- [x] `query_ip_name()` reverse cache hit/miss traced at `TT_COMM|3`.
- [x] Cache statistics (fwd hit/miss/negative, rev hit/miss) tracked in `resolver_telemetry_t` and displayed in `dump_socket_status` DNS Cache Statistics section.
- [x] `RESOLVER_NOBLOCK_001`: enqueue call measured with `std::chrono::steady_clock`; asserts < 50 ms return with 500 ms worker delay hook (proves non-blocking on both backends).
- [x] `RESOLVER_CACHE_001`: pre-populated forward cache hit in `socket_connect`; asserts admitted counter unchanged and `fwd_cache_hit` incremented.

## Stage 5 Completion Summary (2026-03-24 finalized)

**What's Complete:**
- [x] c-ares backend is live under `HAVE_CARES`; fallback (getaddrinfo-in-worker) still active without c-ares.
- [x] Both paths use the same task/result queues, completion key, and public API.
- [x] Admission control and telemetry are now centralized in shared resolver core; socket-layer duplicate admission gates removed.
- [x] Per-class quotas are runtime configurable (`ResolverForwardQuota`, `ResolverReverseQuota`, `ResolverRefreshQuota`) with defaults 10/4/2.
- [x] **Forward Lookup coverage (10/10 passing)**: `socket_connect` hostname path and `resolve()` API coverage are passing.
- [x] **Reverse Lookup coverage (8/8 passing)**: auto reverse-refresh and manual `query_ip_name()` coverage are passing in both the current no-c-ares build and the Windows fetched-c-ares build.
- [x] **Refresh coverage (3/3 passing)**: backend-agnostic peer refresh coverage is passing in both the current no-c-ares build and the Windows fetched-c-ares build.
- [x] Parity verification tests for c-ares path demonstrate identical behavior to fallback path across timeout, dedup, admission, reverse-cache, and refresh scenarios.
- [x] **Test structure separated** into behavior-lockdown (SOCK_BHV_*), operation-extensions (SOCK_OP_*, SOCK_DNS_*, SOCK_RT_*), and resolver-contract (RESOLVER_*) test files.
- [x] **Full no-c-ares resolver matrix is green (25/25)** across Forward, Reverse, and Refresh classes.
- [x] **Full Windows c-ares resolver matrix is green (25/25)** on `vs16-x64` with fetched c-ares.
- [x] **Shared resolver cache ownership complete (2026-03-24)**: Forward and reverse DNS lookup caches migrated from `src/comm.c` to `src/addr_resolver.cpp` with public APIs; TTL-aware caching with runtime-configurable expiry; negative caching support for failed forward lookups; `query_ip_name()` remains immediately-return with background refresh on cache miss.
- [x] **Forward cache integrated into socket_connect (2026-03-24)**: Cache-hit path bypasses DNS worker entirely (`sin_family` guard skips `socket_name_to_sin`); `TT_COMM|3` trace on hit and miss.
- [x] **Forward cache integrated into resolve() / query_addr_number (2026-03-24)**: Cache hit fires callback immediately (returns 0, no async request reserved); `TT_COMM|3` trace on hit and miss.
- [x] **Reverse cache trace instrumentation (2026-03-24)**: `TT_COMM|3` hit/miss trace added to `query_ip_name()` call site in `comm.c`.
- [x] **Cache statistics in dump_socket_status (2026-03-24)**: Forward hit, miss, negative-hit and reverse hit, miss counters added to `resolver_telemetry_t`, tracked in `addr_resolver.cpp`, displayed in DNS Cache Statistics section.
- [x] **Non-blocking invariant verified by test (2026-03-24)**: `RESOLVER_NOBLOCK_001` — installs 500 ms delay hook, measures enqueue call duration (must be < 50 ms), waits for worker result (must arrive within 3 s). Validates both c-ares and fallback backends are non-blocking on main thread.
- [x] **Forward cache bypass validated by test (2026-03-24)**: `RESOLVER_CACHE_001` — pre-populates forward cache, socket_connect with that hostname, asserts admitted counter does NOT increase and `fwd_cache_hit` does increase.
- [x] **Operator-facing Stage 5 behavior documentation published (2026-03-24)**: Documents `resolve()` and `query_ip_name()` async/runtime behavior, tracing, and socket status telemetry.

**Deferred To Stage 6 (Intentional):**
- [ ] Assertion strengthening for resolve()/reverse tests (replace scaffolds/telemetry checks with final async contract assertions).
- [ ] Production-load trace verification under c-ares (`-t TT_COMM|3`) and publication of latency/stall evidence.

## Stage 5 Next-Session Priorities

1. **Stage 6 hardening handoff: assertion strengthening** — Replace telemetry-oriented scaffolds in resolver tests with final callback-contract assertions.

2. **Stage 6 runtime evidence handoff: production-load trace** — Capture and publish c-ares production trace evidence (`-t TT_COMM|3`) for no-main-thread-blocking runtime behavior.

3. **Stage 6 documentation handoff** — Expand from operator-facing guidance into deeper internals and performance evidence docs.

---

## Peer Refresh Backend-Agnostic Readiness Evaluation

### Status: IMPLEMENTED AND PARITY-VERIFIED

Peer refresh tests are implemented and passing in both the current no-c-ares build and the Windows fetched-c-ares build. They remain backend-agnostic because they exercise the public resolver API directly rather than heartbeat scheduling internals.

### Available Test Infrastructure

1. **Interactive Descriptor Management**:
   - `create_test_interactive(obj)` (from `simulate.h` via `fixtures.hpp`): Create interactive user descriptors for testing.
   - `ScopedTestInteractiveAddr`: RAII wrapper to safely manage multiple test interactive descriptors.
   - Enables simulation of multiple concurrent peers with distinct IPs.

2. **Reverse/Refresh Enqueue APIs** (backend-neutral):
   - `addr_resolver_enqueue_reverse(cache_addr, ip_string, deadline)`: Directly enqueue reverse-cache refresh.
   - `addr_resolver_enqueue_refresh(cache_addr, ip_string, deadline)`: Directly enqueue peer refresh.
   - Works identically on both c-ares and fallback backends.
   - No heartbeat simulation needed—tests can directly enqueue refresh requests.

3. **Completion Polling** (backend-neutral):
   - `handle_dns_completions()`: Process pending DNS completion events.
   - `addr_resolver_dequeue_result()`: Fetch completed results.
   - Both work the same way regardless of backend.

4. **Telemetry and State Inspection**:
   - `get_dns_telemetry_snapshot()`: Check in-flight, admitted, dedup-hit, timed-out counters.
   - `get_socket_operation_info()`: Inspect operation state and phase (if needed for integration).
   - Both available and stable across backends.

5. **Test Injection Hooks**:
   - `addr_resolver_set_lookup_test_hook()`: Inject query rewrites, delays, or stale values.
   - Works identically on both backends.
   - Enables deterministic testing of coalescing, timeout, and stale-refresh scenarios.

### Test Design (Backend-Agnostic)

Proposed peer refresh test family (RESOLVER_REFRESH_001–003):

1. **RESOLVER_REFRESH_001_BasicRefresh_EnqueueProcessComplete**:
   - Create an interactive descriptor with IP "127.0.0.2".
   - Enqueue reverse-cache refresh for that IP.
   - Poll completions; verify result is dequeued.
   - Verify telemetry shows +1 admitted.

2. **RESOLVER_REFRESH_002_Coalescing_MultipleIPsCoalesce**:
   - Create two interactive descriptors: one with "127.0.0.2", one with "127.0.0.3".
   - Enqueue reverse-cache refresh for both IPs *simultaneously* (without dequeueing first).
   - Install resolver hook that rewrites both to same effective address.
   - Poll completions; verify both results coalesce on same resolved value.
   - Verify telemetry shows dedup-hit counter incremented.

3. **RESOLVER_REFRESH_003_TimeoutAndCleanup_SafeStateAfterExpiry**:
   - Create interactive descriptor with IP "127.0.0.2".
   - Install timeout hook to force timeout.
   - Enqueue reverse-cache refresh with short deadline.
   - Destroy the interactive descriptor while refresh is pending.
   - Poll completions; verify result marks timeout.
   - Verify no stale callbacks or memory leaks.

### Why This Tests Backend-Agnostic Contract

These tests touch only the public resolver API (`addr_resolver_enqueue_reverse`, `addr_resolver_dequeue_result`, `handle_dns_completions`) and test hooks. Both c-ares and fallback backends export the same API, so:
- Tests pass on both `HAVE_CARES` and non-c-ares builds.
- Backend choice is transparent to test logic.
- Parity is guaranteed by testing the same entry points.

### No Heartbeat Simulation Required

Peer refresh's *production* behavior is triggered by heartbeat events (periodic interactive refresh). However, tests don't need to simulate heartbeat—they directly exercise the enqueue/dequeue pathways that heartbeat would invoke. This decouples test coverage from the heartbeat scheduler's implementation details.

---

## Testing Strategy

### Matrix Verification Tests
Use a merged API-first grid. Backend variants are split only for backend-specific parity assertions.

| Class | Canonical API test family | Existing test ID families | Merge policy |
|---|---|---|---|
| **Forward** | `RESOLVER_FWD_001` through `RESOLVER_FWD_010` (socket_connect + resolve paths) | `RESOLVER_FWD_*` | Unified API suite; no backend split where backend is not under test |
| **Reverse** | `RESOLVER_REV_001` through `RESOLVER_REV_008` (auto + manual) | `RESOLVER_REV_*` | Unified API suite; passing in current no-c-ares build |
| **Refresh** | `RESOLVER_REFRESH_001` through `RESOLVER_REFRESH_003` | `RESOLVER_REFRESH_*` | Unified API suite; passing in current no-c-ares build |

**Subtests per case**:
1. Basic success path (hostname resolves).
2. Cache hit (repeat request; verify no queue).
3. Timeout (configure short TTL; verify timeout error).
4. Admission control overflow (queue full; verify rejection).
5. Owner/object destruction during pending request (verify safe cleanup, no callback to freed object).

---

## Decisions Locked

1. **Fallback resolver backend choice**: use standard `getaddrinfo` in worker threads for non-c-ares builds.
   - Rationale: simplest and most portable fallback while preserving non-blocking main-loop behavior.
   - Trade-off: higher latency without c-ares is accepted.

2. **resolve() and query_ip_name() async contract shape**: use async completion callback pattern.
   - Rationale: consistent with the socket-connect async flow and resolver worker model.
   - Follow-up: documentation and mudlib updates remain required.

3. **query_ip_name() return value on cache miss**: return numeric IP string immediately; schedule async reverse refresh in background.
   - Rationale: preserves legacy non-blocking fallback contract and avoids nil-handling regressions in existing mudlibs.
   - Trade-off: caller receives a stale (numeric) value until the background refresh completes and updates the cache.

---

## Performance Expectations

| Build | Small Hostname | Cached Hostname | Timeout |
|-------|---|---|---|
| **WITH c-ares** | 10–100 ms (c-ares worker latency) | <1 ms (cache hit) | 5–10 s (default timeout) |
| **WITHOUT c-ares** | 50–500 ms (getaddrinfo + worker latency) | <1 ms (cache hit) | 5–10 s (default timeout) |

**Main loop impact**: zero stalls in both cases (all work in worker threads).

---

## Rollout Risk & Mitigation

**Risk: resolve() and query_ip_name() async contract breaks existing LPC code.**
- Mitigation: Publish deprecation notice with timeline; provide mudlib helper for async migration and staged rollout guidance.

**Risk: Without c-ares, fallback resolver is slow (500 ms latency).**
- Mitigation: Document performance expectations; recommend c-ares for production; default build includes c-ares support.

**Risk: Admission control rejects legitimate requests under peak load.**
- Mitigation: Tune caps (global 64, per-owner 8) based on mudlib telemetry; add observability counters; publish tuning guide for operators.

**Risk: Legacy addr_server_fd path had specific behavior (e.g., timeout values) that changes.**
- Mitigation: Preserve timeout contract; document any behavior deltas before Stage 5 completion; provide migration guide.

---

## Parity Test Progress (2026-03-24)

Parity coverage is now tracked in the three-class model. API-level tests are merged where c-ares and no-c-ares use the same contract, and backend-split runs are retained only for parity-sensitive assertions.

### Test Coverage Status

**Forward (COMPLETE)**
- [x] `RESOLVER_FWD_001`–005 (socket_connect hostname flow): 5/5 passing
- [x] `RESOLVER_FWD_006`–010 (resolve() API scaffolds): 5/5 passing
- **Merged status**: 10/10 passing

**Reverse (COMPLETE IN CURRENT NO-CARES BUILD)**
- [x] `RESOLVER_REV_001`–003 (auto reverse-refresh): 3/3 passing
- [x] `RESOLVER_REV_004`–008 (manual `query_ip_name()` coverage): 5/5 passing
- **Merged status**: 8/8 passing

**Refresh (COMPLETE IN CURRENT NO-CARES BUILD)**
- [x] `RESOLVER_REFRESH_001`–003 (peer refresh background): 3/3 passing
- **Merged status**: 3/3 passing

### Test Infrastructure

**Available utilities**:
- Resolver parity file: [tests/test_socket_efuns/test_socket_efuns_resolver.cpp](tests/test_socket_efuns/test_socket_efuns_resolver.cpp)
- Core socket behavior file: [tests/test_socket_efuns/test_socket_efuns_behavior.cpp](tests/test_socket_efuns/test_socket_efuns_behavior.cpp)

Resolver-focused utilities:
- `handle_dns_completions()`: Poll DNS completion queue
- `WaitForDNSCompletion()`: Block until DNS operation completes
- `get_dns_telemetry_snapshot()`: Inspect admitted/dedup/timed_out counters
- `ScopedDnsTimeoutHook`: Install DNS timeout hook for test scenarios
- `get_socket_operation_info()`: Inspect socket operation state and phase

**Test conventions**:
- Telemetry assertions: Verify admission/dedup/timeout counters change as expected
- Timeout testing: Use `ScopedDnsTimeoutHook` to force deterministic timeout
- Load testing: Verify system robustness under concurrent DNS requests without crashes
- Cleanup testing: Verify no stale callbacks after object destruction
- Consolidation policy: keep a single canonical API test family when backend behavior is not the assertion target

### Next Steps

1. **Stage 5 is finalized**: shared resolver migration, cache integration, tracing, telemetry, and operator-facing documentation are complete.
2. **Stage 6 hardening**: strengthen callback-contract assertions for resolver tests.
3. **Stage 6 runtime evidence**: capture and publish production-load c-ares trace evidence.

---

## Conclusion

Stage 5 enables a non-blocking shared resolver with three key properties:

1. **Non-blocking by design**: all DNS work in worker threads; main loop never blocks.
2. **Adaptive backend**: with c-ares for production performance, fallback for compatibility.
3. **Deterministic completion**: every request reaches exactly one terminal state (success, timeout, cancel, error).

The behavior matrix ensures that operators and LPC developers understand what changes between builds and across operation families, enabling informed deployment decisions.
